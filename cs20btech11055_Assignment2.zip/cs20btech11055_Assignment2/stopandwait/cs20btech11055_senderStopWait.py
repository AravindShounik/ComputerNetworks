import socket
import time
import struct
# import packet
senderIP = "10.0.0.1"
senderPort   = 20001
recieverAddressPort = ("10.0.0.2", 20002)
bufferSize  = 1024 #Message Buffer Size
serialNumbersize = 4
TIME = 0.1

# Create a UDP socket at reciever side
socket_udp = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)

filename = 'testFile.jpg'

f = open(filename,'rb')
print(f)
i = 0
isEOF = False

msg = f.read(1010)
NumberofReTransmissions = 0
start = time.time()
while True:
    # i += 1
    # Send to server using created UDP socket
    # msg = input("Please enter message to send: ")
    # message = str.encode(msg)
    # print(f"msg is {msg}")
    if msg == b'':
        isEOF = True
    # tup = {msg, a}
    if isEOF:
        message = struct.pack('1010s i i', msg, i, 1)
    else:
        message = struct.pack('1010s i i', msg, i, 0)
    
    # print(msg)
    # print(len(a))
    # message = packet.make(msg,i,isEOF)
    socket_udp.sendto(message, recieverAddressPort)
    try:
        while True:
            #wait for reply message from reciever
            socket_udp.settimeout(TIME)
            # print("HI")
            msgFromServer = socket_udp.recvfrom(bufferSize)
            ack = struct.unpack('i',msgFromServer[0])[0]
            # print(f"Acknowledgement{ack} recieved")
            if ack == i:
                i += 1
                msg = f.read(1010)
                break
            
    except:
        NumberofReTransmissions+=1
        continue
    # print(msgString)
    # time.sleep(0.01)
    if isEOF:
        break
    # break
end = time.time() - start
print(f'Number of Retransmissions: {NumberofReTransmissions}')
print(f'Average Throughput {1145.0/end}')
f.close()
socket_udp.close()