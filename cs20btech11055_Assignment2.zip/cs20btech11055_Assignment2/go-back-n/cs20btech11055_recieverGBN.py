import socket
import struct

recieverIP = "10.0.0.2"
recieverPort   = 20002
bufferSize  = 1024 #Message Buffer Size
serialNumbersize = 16

# bytesToSend = str.encode(msgFromServer)

# Create a UDP socket
socket_udp = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)

# Bind socket to localIP and localPort
socket_udp.bind((recieverIP, recieverPort))

print("UDP socket created successfully....." )

filename = 'testFile1.jpg'

f = open(filename, 'wb')
i = 0
while True:

    #wait to recieve message from the server
    bytesAddressPair = socket_udp.recvfrom(bufferSize)
    # print(bytesAddressPair) #print recieved message

    #split the recieved tuple into variables
    recievedMessage = bytesAddressPair[0]
    senderAddress = bytesAddressPair[1]

    msg, serialNumber = struct.unpack('1010s i', recievedMessage)
    # serialNumber = int.from_bytes(recievedMessage[bufferSize-serialNumbersize-1:-1],'big')
    # isEOF = recievedMessage[-1:]
    # print(len(recievedMessage))
    # print(f'serialNumber {serialNumber}')
    
    # print(msg,serialNumber)
    print(f"Recieved Packet {serialNumber}")
    if serialNumber == i:
        message = struct.pack('i',serialNumber)
        socket_udp.sendto(message, senderAddress)
        f.write(msg)
        i+=1
    else:
        message = struct.pack('i',i-1)
        socket_udp.sendto(message,senderAddress)
        continue
    # break
    if msg == b'':
        break

f.close()
socket_udp.close()