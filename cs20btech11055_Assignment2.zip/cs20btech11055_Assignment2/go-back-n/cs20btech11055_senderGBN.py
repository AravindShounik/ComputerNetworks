from multiprocessing import Process, Manager, Value, Array
import socket
import time
import struct
bufferSize  = 1024 #Message Buffer Size
serialNumbersize = 4
TIME = 0.075

def recvAck(socket_udp, base, current,k):
    msgfromServer = socket_udp.recvfrom(bufferSize)
    ack = struct.unpack('i',msgfromServer[0])[0]
    # print(f'Recieved Ack{ack}')
    if ack == base.value:
        base.value+=1
        k = 1
        
    elif ack > base.value:
        # print(f'Recieved Ack{ack}')
        base.value = ack
        k = 1
    # else:
        # print(f'Recieved Ack{ack}')

    # print("Hellp World")

def sendPack(socket_udp, base, WINDOW_SIZE, current,chuncks, recieverAddressPort):
    while True:
        # print("Hello World!")
        if current.value < base.value + WINDOW_SIZE and current.value < len(chuncks):
            data = chuncks[current.value]
            msg = struct.pack('1010s i', data, current.value)
            socket_udp.sendto(msg, recieverAddressPort)
            # print(f'Sent packet {current.value}')
            # print()
            current.value +=1
        if base.value >=len(chuncks):
            break


if __name__=='__main__':
    # import packet
    senderIP = "10.0.0.1"
    senderPort   = 20001
    recieverAddressPort = ("10.0.0.2", 20002)
    
    base = Value('i',0)
    current = Value('i',0)
    k = Value('i',0)
    chuncks = []
    WINDOW_SIZE = 32

    # Create a UDP socket at reciever side
    socket_udp = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)

    filename = 'testFile.jpg'

    f = open(filename,'rb')
    # print(f)
    # i = 0
    # isEOF = False
    data = f.read(1010)
    while data != b'':
        chuncks.append(data)
        data = f.read(1010)


    p1 = Process(target=sendPack, args=(socket_udp, base, WINDOW_SIZE, current, chuncks, recieverAddressPort))
    start = time.time()

    p1.start()
    while True:
        p2 = Process(target=recvAck, args=(socket_udp,base,current,k))
        p2.start()
        p2.join(timeout=TIME)

        if p2.is_alive():
            p2.terminate()
            if not k.value:
                # print("Here")
                current.value = base.value
                # print(current.value)
                k.value = 0
        if current.value == len(chuncks) -1:
            end = time.time() - start
        if p1.is_alive():
            continue
        else:
            break
        
        